package edu.monmouth.cs176.s1233625lab2;

public class StudentList {

	Student[] cs176Students;
	
	private int count = 0;
	
	
	/**
	 * Constructor for StudentList Class
	 */
	StudentList (int totatStudents) {
		cs176Students = new Student [totatStudents];
	}
	
	/**
	 * @param s - new student object
	 */
	public void addStudent (Student s) {
		cs176Students[count] = s;
		count++;
	}
	
	/**
	 * List the students using for-each loop
	 */
	public void listStudents() {
		for (Student s: cs176Students) {
			System.out.println(s.toString());
		}
	}
	
	public Student find (String studentID) {
		for (Student s: cs176Students) {
			if (s.getsID() == studentID)//going through student list and seeing if student id matches
			{
				return s;
			}
			

		}
		return null;
	} 
	
	public boolean updateStudentGraduationYear(String studentID, Integer year) {
		 
			Student findstudent = find(studentID);
			
			if(findstudent != null)
			{
				findstudent.setGraduaitonYear(year);
				return true;
			}
			else 
			{
				return false;
			}
				
		
	}

}
