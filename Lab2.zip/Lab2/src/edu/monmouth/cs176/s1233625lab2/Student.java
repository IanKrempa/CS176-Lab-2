package edu.monmouth.cs176.s1233625lab2;

public class Student {

	private String name;
	private String studentID;
	private String email;
	private String major;
	private Integer classLevel;
	private String advisor;
	private Double credits;
	private Integer graduationYear;
	
	/**
	 * @param name - full name
	 * @param sID - student ID
	 * @param email - school email
	 * @param major - student's major
	 * @param classlevel - class level 1 thru 4
	 * @param advisor - student's advisor
	 * @param credits - course credit
	 * @param graduationYear - graduation year
	 */
	
	Student (String name, String sID, String email, String major, Integer classLevel ,
			String advisor, Double credits, Integer year) {
		this.name = name;
		this.studentID = sID;
		this.email = email;
		this.major = major;
		this.classLevel = classLevel;
		this.advisor = advisor;
		this.credits = credits;
		this.graduationYear = year;
	}

	
	/**
	 * Getting method for major
	 * @param major
	 */
	public void setMajor (String major) {
		this.major = major;
		
	}
	
	public String getMajor () {
		return this.major;
		
	}
	
	public void setGraduaitonYear (Integer graduationYear) {
		this.graduationYear = graduationYear;
	}
	
	public String getsID () {
		return this.studentID;
	}
	// over object to return string
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return
				"Name: " + this.name + "\n" +
				"Student ID: " + this.studentID + "\n" +
				"Email: " + this.email + "\n" +
				"Major: " + this.major + "\n" +
				"Class: " + this.classLevel + "\n" +
				"Advisor: " + this.advisor + "\n" +
				"Credits: " + this.credits + "\n" +
				"Graduation Year: "+ this.graduationYear;
				
				
	}
}
